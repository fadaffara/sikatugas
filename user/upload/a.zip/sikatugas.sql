-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2025 at 04:21 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikatugas`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `reset_token` varchar(64) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `name`, `photo`, `reset_token`, `token_expiry`) VALUES
(1, 'timchill100@gmail.com', '$2y$10$uumMoCbJ2cwofFu6JVVEGuv96AQ51KMsLtrbV95FaiMDlARXvx3.C', 'Tim Chill', 'someone with a  ee876180-29b0-453b-a45d-c9706492a4dd.png', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi`
--

CREATE TABLE `notifikasi` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_seen` tinyint(1) DEFAULT 0,
  `is_hidden` tinyint(1) DEFAULT 0,
  `admin_id` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `nama_tugas` varchar(255) NOT NULL,
  `ditugaskan` varchar(50) NOT NULL,
  `detail_tugas` varchar(255) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `deadline` date NOT NULL,
  `status` enum('Belum Dimulai','Sedang Dikerjakan','Menunggu Approval','Butuh Revisi','Selesai','Gagal') DEFAULT 'Belum Dimulai',
  `prioritas` enum('Rendah','Sedang','Tinggi','') NOT NULL,
  `file_pengumpulan` varchar(255) DEFAULT NULL,
  `file_admin` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `nama_tugas`, `ditugaskan`, `detail_tugas`, `tanggal_mulai`, `deadline`, `status`, `prioritas`, `file_pengumpulan`, `file_admin`) VALUES
(103, 'Fotocopy faktur pajak', 'mojima_tatsuyaa', 'Silakan fotocopy yang sudah ada kemudian kirim dalam bentuk pdf beserta penjelasannya', '2025-01-11', '2025-01-10', 'Belum Dimulai', 'Sedang', '', 'Home Alone 2 - Lost in New York (USA)_8.zip'),
(108, 'Dokumentasi Program Go Green', 'mojima_tatsuyaa', 'Kirimkan semua foto dan video yang telah dicapture tanpa dikompres ', '2025-01-20', '2025-01-23', 'Sedang Dikerjakan', 'Tinggi', '', 'a.rar'),
(109, 'Laporan Dana Expo Mei 2025', 'mojima_tatsuyaa', 'Buat laporan keseluruhan dana expo mei di excel menggunakan vlookup', '2025-01-20', '2025-01-29', 'Menunggu Approval', 'Rendah', 'a.rar', 'a_1.rar');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tanggal_dibuat` timestamp NOT NULL DEFAULT current_timestamp(),
  `token_aktivasi` varchar(64) DEFAULT NULL,
  `token_reset` varchar(64) DEFAULT NULL,
  `token_kedaluwarsa` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `foto`, `email`, `password`, `tanggal_dibuat`, `token_aktivasi`, `token_reset`, `token_kedaluwarsa`) VALUES
(1, 'Dechris Jack', 'dechris_1140', '1736540816-someone is stud de61661d-c3b2-4613-bebb-e143d990e1c8.png', 'dechris4410@gmail.com', '$2y$10$hksNcDSWU7gg15xQTNZUHOmgcMAis.GY/uEQrbWwrWKjpl2xTtcOa', '2024-10-01 04:16:34', NULL, '89d823227511efeb7dc4eb00d614188cdca25ac8a886be493875208f43fb3276', '2025-01-20 08:53:32'),
(17, 'Tatsuya Mojima', 'mojima_tatsuyaa', '1744251087-someone with a  ee876180-29b0-453b-a45d-c9706492a4dd.png', 'daffabanyumas01@gmail.com', '$2y$10$zOqkVSEPIEn5xTCR0paKXOBptB.DnEA17HIW8XoPtIwZPuRrlDGvm', '2024-12-03 02:23:59', NULL, NULL, NULL),
(26, 'Fajar Nugros', 'fajarnugros_123', '1734506481-someone learnin 165c8a96-2512-4a62-8926-2207a5618b63.png', 'kgelas966@gmail.com', '$2y$10$aKFGDTj/KqnpjrKoaDGNeeZQ3NzI/aozhS7AlqZMGbn4Ometfs5BK', '2024-12-18 04:32:18', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `reset_token` (`reset_token`);

--
-- Indexes for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_ditugaskan` (`ditugaskan`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `token_aktivasi` (`token_aktivasi`),
  ADD UNIQUE KEY `token_reset` (`token_reset`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notifikasi`
--
ALTER TABLE `notifikasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD CONSTRAINT `notifikasi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifikasi_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `fk_ditugaskan` FOREIGN KEY (`ditugaskan`) REFERENCES `users` (`username`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
